
# matched_filter_echo_detector.py
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import correlate

def matched_filter(signal, template):
    correlation = correlate(signal, template, mode='same')
    snr = np.max(np.abs(correlation)) / np.std(correlation)
    return correlation, snr

def simulate_echo_signal(length, delay_s, noise_level=0.3):
    t = np.linspace(0, 1, length)
    signal = np.sin(2 * np.pi * 50 * t) * np.exp(-100 * (t - 0.2)**2)
    echo = 0.8 * np.sin(2 * np.pi * 50 * t) * np.exp(-100 * (t - 0.2 - delay_s)**2)
    noise = noise_level * np.random.randn(length)
    return signal + echo + noise, signal

def main():
    length = 10000
    delay_s = 0.292
    data, template = simulate_echo_signal(length, delay_s)
    correlation, snr = matched_filter(data, template)
    print(f"Predicted Echo Delay: {delay_s} s | SNR: {snr:.2f}")
    plt.plot(correlation)
    plt.title("Matched Filter Correlation")
    plt.savefig("Echo_Correlation_Results.png")

if __name__ == "__main__":
    main()
