
# constants.py
c = 299792458  # Speed of light in m/s
