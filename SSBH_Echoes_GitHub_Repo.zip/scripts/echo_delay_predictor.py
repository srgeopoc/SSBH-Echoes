
# echo_delay_predictor.py
from constants import c

def predict_echo_delay(length_meters):
    return 2 * length_meters / c

def resonance_frequency(length_meters):
    return c / (4 * length_meters)
